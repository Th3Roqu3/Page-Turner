
var bytutorialEbookApp = angular.module('bytutorialEbookApp', ['ngRoute']);


angular.element(document).ready(function () {
    if (window.cordova) {
      document.addEventListener('deviceready', function () {
        angular.bootstrap(document.body, ['bytutorialEbookApp']);
      }, false);
    } else {
      angular.bootstrap(document.body, ['bytutorialEbookApp']);
    }
});


bytutorialEbookApp.controller('chapterController', ['$scope', function ($scope) {
	
	var slideout = new Slideout({
		'panel': document.getElementById('panel'),
		'menu': document.getElementById('menu'),
		'padding': 0,
		'tolerance': 70,
		touch: true
	});

	
	document.querySelector('#main-button').addEventListener('click', function() {
		slideout.toggle();
	});

	
	$("#menu-list > li > a").on("click", function(){
		
		if($("html").hasClass("slideout-open")){
			slideout.toggle();
		}
	});
	
	
	
	function animateMe(myObject, animateType, duration){
		$(myObject).addClass("animated " + animateType).css("animation-delay", duration + "s");
	}
	
	
	animateMe("#box-content", "fadeIn", 0.1);
}]); 